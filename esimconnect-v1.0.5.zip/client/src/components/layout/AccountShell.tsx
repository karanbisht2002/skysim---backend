import { Redirect, Route, Switch, useLocation } from 'wouter';
import { AccountLayout } from '@/components/layout/AccountLayout';
import Profile from '@/pages/Profile';
import MyESIMs from '@/pages/MyESIMs';
import MyOrders from '@/pages/MyOrders';
import Referrals from '@/pages/Referrals';
import AccountSupport from '@/pages/AccountSupport';
import KYCSubmission from '@/pages/KYCSubmission';
import AccountGiftCards from '@/pages/AccountGiftCards';

export function AccountShell() {
  const [location] = useLocation();

  // Handle the base /account route or unknown sub-paths
  if (location === '/account' || location === '/account/') {
    return <Redirect to="/account/profile" />;
  }

  return (
    <AccountLayout>
      <Switch>
        <Route path="/account/profile" component={Profile} />
        <Route path="/account/esims" component={MyESIMs} />
        <Route path="/account/orders" component={MyOrders} />
        <Route path="/account/referrals" component={Referrals} />
        <Route path="/account/support" component={AccountSupport} />
        <Route path="/account/kyc" component={KYCSubmission} />
        <Route path="/account/gift-cards" component={AccountGiftCards} />
        
        {/* Fallback for unmatched /account/* routes */}
        <Route>
          <Redirect to="/account/profile" />
        </Route>
      </Switch>
    </AccountLayout>
  );
}
